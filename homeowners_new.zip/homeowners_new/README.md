# Homeowners Claim and Fraud Prevention 
## USC Team Members
  * Nick Roewe, roewe@usc.edu
  * Henry Keane, hkeane@usc.edu
  * Mingyuan (Molly) He, mingyuah@usc.edu
  * Aneesh Bhamidipati, abhamidi@usc.edu
  
## What Is Included
### Deliverable 2 (9/17): Frontend UI and Single Sign-On
1. In the UI, user can enter claim, search for claim info and property history.
2. Single sign-on allows user to login with single ID/password and gain access to the connected system using LDAP.
