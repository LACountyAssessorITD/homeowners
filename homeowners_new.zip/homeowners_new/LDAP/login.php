<?php
include_once "authenticate.php";
include_once "constants.php";
session_start();

	$ldapusername = "laassessor"."\\".$_POST["username"];
	$_SESSION['USERNAME']=$_POST["username"];
	$ldappassword = $_POST["password"];
	$_SESSION['password']=$_POST["password"];

	if (!authenticateUser($ldapusername, $ldappassword)) {
		$_SESSION["logged_in"] = FALSE;
		$url = "../index.php?loginfail=true";
		header("Location:" . $url);
		exit();
	} else {
		// if authencate successfully, get relative info
		$user_name=$_POST["username"];
		$serverName = "HTRAINTRACDEV-V";
		$uid = "superadmin";
		$pwd = 'admin';
		$databaseName = "homeowner_test";

		$connectionInfo = array( "UID"=>$uid,
		    "PWD"=>$pwd,
		    "Database"=>$databaseName);

		/* Connect using SQL Server Authentication. */
		$conn = sqlsrv_connect( $serverName, $connectionInfo);
		$tsql = "SELECT id, username, password, name FROM temp_table";

		/* Execute the query. */

		$stmt = sqlsrv_query( $conn, $tsql);

		if ( $stmt )
		{
		}
		else
		{
		    echo "Error in statement execution.\n";
		    die( print_r( sqlsrv_errors(), true));
		}

		/* Iterate through the result set printing a row of data upon each iteration.*/
		//$loggedIn='false';
		if($_SESSION["name"]==null){
		    while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_NUMERIC))
		    {
		        if(strcmp($_POST["username"], $row[1])==0){
		            $_SESSION["name"] = $row[3];
		        }
		    }
		}

		// if login invalid, redirect back to login page
		//  so login page displays errer message
		//commented this out cause im testing single sign on

		if ($_SESSION["name"]==null) {
		    $url = "../index.php?loginfail=true";
		    header("Location:" . $url);
		    exit();
		}
		else{
			$url = "../home_page.php";
		    header("Location:" . $url);
		    exit();
		}
		/* Free statement and connection resources. */
		sqlsrv_free_stmt( $stmt);
		sqlsrv_close( $conn);
		echo "<h1> You are logged in as ".$_SESSION["name"];
	}
?>
